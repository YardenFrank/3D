__author__ = 'Yarden Frank'
from Client_Server.Client import Client


def main():
    try:
        Client()
    except KeyboardInterrupt:
        print('\nProgram Terminated')


if __name__ == '__main__':
    main()
