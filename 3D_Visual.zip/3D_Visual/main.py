__author__ = 'Yarden Frank'
from Client_Server.Client import Client
from Client_Server.Server import Server
from threading import Thread


def main():
    try:
        Thread(target=lambda: Server()).start()
        Client()
    except KeyboardInterrupt:
        print('\nProgram Terminated')


if __name__ == '__main__':
    main()
